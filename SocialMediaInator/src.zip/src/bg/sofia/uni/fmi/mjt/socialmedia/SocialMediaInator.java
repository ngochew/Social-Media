package bg.sofia.uni.fmi.mjt.socialmedia;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

import bg.sofia.uni.fmi.mjt.socialmedia.content.Content;
import bg.sofia.uni.fmi.mjt.socialmedia.exceptions.ContentNotFoundException;
import bg.sofia.uni.fmi.mjt.socialmedia.exceptions.NoUsersException;
import bg.sofia.uni.fmi.mjt.socialmedia.exceptions.UsernameAlreadyExistsException;
import bg.sofia.uni.fmi.mjt.socialmedia.exceptions.UsernameNotFoundException;

public interface SocialMediaInator {


    void register(String username) throws UsernameAlreadyExistsException;

    String publishPost(String username, LocalDateTime publishedOn, String description) throws UsernameNotFoundException;

    String publishStory(String username, LocalDateTime publishedOn, String description)
            throws UsernameNotFoundException;

    void like(String username, String id) throws UsernameNotFoundException, ContentNotFoundException;

    void comment(String username, String text, String id) throws UsernameNotFoundException, ContentNotFoundException;

    Collection<Content> getNMostPopularContent(int n);

    Collection<Content> getNMostRecentContent(String username, int n) throws UsernameNotFoundException;

    String getMostPopularUser() throws NoUsersException;

    Collection<Content> findContentByTag(String tag);

    List<String> getActivityLog(String username);

}