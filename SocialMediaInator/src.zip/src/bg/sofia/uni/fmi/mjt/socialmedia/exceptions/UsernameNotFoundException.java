package bg.sofia.uni.fmi.mjt.socialmedia.exceptions;

public class UsernameNotFoundException extends Exception {
}
