package bg.sofia.uni.fmi.mjt.socialmedia.exceptions;

public class ContentNotFoundException extends Exception{
}
